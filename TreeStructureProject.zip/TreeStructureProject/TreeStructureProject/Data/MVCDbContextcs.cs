﻿using Microsoft.EntityFrameworkCore;
using TreeStructureProject.Models.Domain;

namespace TreeStructureProject.Data
{
    public class MVCDbContextcs : DbContext
    {
        public MVCDbContextcs(DbContextOptions options) : base(options)
        {
        }

        public DbSet<NodesofNode>  Nodes { get; set; }
    }
}
