﻿using System.ComponentModel.DataAnnotations;

namespace TreeStructureProject.Models.Domain
{
    public class NodesofNode
    {
        [Key]
        public int NodeId { get; set; }

        public string? NodeName { get; set; }

        public int ParentNodeId { get; set; }

        public bool IsActive{ get; set; }

        public DateTime StartTime { get; set; }
    }
}
