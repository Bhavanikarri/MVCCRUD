﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TreeStructureProject.Data;
using TreeStructureProject.Models.Domain;

namespace TreeStructureProject.Controllers
{
    public class NodesofNodesController : Controller
    {
        private readonly MVCDbContextcs _context;

        public NodesofNodesController(MVCDbContextcs context)
        {
            _context = context;
        }

        // GET: NodesofNodes
        public async Task<IActionResult> Index()
        {
              return _context.Nodes != null ? 
                          View(await _context.Nodes.ToListAsync()) :
                          Problem("Entity set 'MVCDbContextcs.Nodes'  is null.");
        }

        // GET: NodesofNodes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Nodes == null)
            {
                return NotFound();
            }

            var nodesofNode = await _context.Nodes
                .FirstOrDefaultAsync(m => m.NodeId == id);
            if (nodesofNode == null)
            {
                return NotFound();
            }

            return View(nodesofNode);
        }

        // GET: NodesofNodes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: NodesofNodes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NodeId,NodeName,ParentNodeId,IsActive,StartTime")] NodesofNode nodesofNode)
        {
            if (ModelState.IsValid)
            {
                _context.Add(nodesofNode);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(nodesofNode);
        }

        // GET: NodesofNodes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Nodes == null)
            {
                return NotFound();
            }

            var nodesofNode = await _context.Nodes.FindAsync(id);
            if (nodesofNode == null)
            {
                return NotFound();
            }
            return View(nodesofNode);
        }

        // POST: NodesofNodes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NodeId,NodeName,ParentNodeId,IsActive,StartTime")] NodesofNode nodesofNode)
        {
            if (id != nodesofNode.NodeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(nodesofNode);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NodesofNodeExists(nodesofNode.NodeId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(nodesofNode);
        }

        // GET: NodesofNodes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Nodes == null)
            {
                return NotFound();
            }

            var nodesofNode = await _context.Nodes
                .FirstOrDefaultAsync(m => m.NodeId == id);
            if (nodesofNode == null)
            {
                return NotFound();
            }

            return View(nodesofNode);
        }

        // POST: NodesofNodes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Nodes == null)
            {
                return Problem("Entity set 'MVCDbContextcs.Nodes'  is null.");
            }
            var nodesofNode = await _context.Nodes.FindAsync(id);
            if (nodesofNode != null)
            {
                _context.Nodes.Remove(nodesofNode);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NodesofNodeExists(int id)
        {
          return (_context.Nodes?.Any(e => e.NodeId == id)).GetValueOrDefault();
        }
    }
}
